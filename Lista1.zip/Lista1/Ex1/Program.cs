﻿using System;
/*using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;*/

namespace Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // cw + tab = abreviação do Console.WriteLine();
            Console.WriteLine("Olá mundo!");
            Console.WriteLine("Bom dia, viu.");
            Console.ReadLine();
        }
    }
}
