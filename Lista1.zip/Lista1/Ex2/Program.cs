﻿using System;
/*using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;*/

namespace Ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // cw + tab = abreviação do Console.WriteLine();
            Console.WriteLine("Olá mundo 2!");
            Console.WriteLine("Boa tarde, viu.");
            Console.ReadLine();
        }
    }
}
